class TournamentMatch {
  final String id;
  final String title;
  final String stage;
  final String type; // 'paid' or 'free'
  final String map;
  final String time;
  final int slots;
  final int currentSlots;
  final int prizePool;
  final int entryFee;
  final String upiId;
  final bool upiEnabled;
  final bool qrEnabled;
  final String? qrDataURL;
  final String groups;
  final String? roomId;
  final String? roomPass;
  final Map<String, dynamic> groupRooms;
  final Map<String, String> whatsappMap;
  final List<dynamic>? publishedScoreboards;
  final String createdBy;
  final String status; // 'open', 'not_started', 'playing', 'ended'

  TournamentMatch({
    required this.id,
    required this.title,
    required this.stage,
    required this.type,
    required this.map,
    required this.time,
    required this.slots,
    required this.currentSlots,
    required this.prizePool,
    required this.entryFee,
    required this.upiId,
    required this.upiEnabled,
    required this.qrEnabled,
    this.qrDataURL,
    required this.groups,
    this.roomId,
    this.roomPass,
    required this.groupRooms,
    required this.whatsappMap,
    this.publishedScoreboards,
    required this.createdBy,
    required this.status,
  });

  factory TournamentMatch.fromMap(Map<String, dynamic> map, String id) {
    return TournamentMatch(
      id: id,
      title: map['title'] ?? 'Custom Match',
      stage: map['stage'] ?? 'Semifinals',
      type: map['type'] ?? 'paid',
      map: map['map'] ?? 'Bermuda',
      time: map['time'] ?? 'Today 8 PM',
      slots: map['slots'] ?? 12,
      currentSlots: map['currentSlots'] ?? 0,
      prizePool: int.tryParse(map['prize'].toString()) ?? 500,
      entryFee: int.tryParse(map['fee'].toString()) ?? 50,
      upiId: map['upiId'] ?? 'sattapai@oksbi',
      upiEnabled: map['upiEnabled'] != false,
      qrEnabled: map['qrEnabled'] != false,
      qrDataURL: map['qrDataURL'],
      groups: map['groups'] ?? 'TEAM A, TEAM B',
      roomId: map['roomId'],
      roomPass: map['roomPass'],
      groupRooms: Map<String, dynamic>.from(map['groupRooms'] ?? {}),
      whatsappMap: Map<String, String>.from(map['whatsappMap'] ?? {}),
      publishedScoreboards: map['publishedScoreboards'],
      createdBy: map['createdBy'] ?? '',
      status: map['status'] ?? 'open',
    );
  }
}
