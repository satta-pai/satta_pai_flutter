import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../models/battle_pass_model.dart';
import '../widgets/cyber_components.dart';

class BattlePassScreen extends StatelessWidget {
  const BattlePassScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    final firestore = Provider.of<FirestoreService>(context);
    final user = auth.currentUser;
    final tiers = SeasonCatalog.seasons[firestore.activeSeason] ?? SeasonCatalog.seasons['S1']!;

    return Scaffold(
      appBar: AppBar(
        title: Text('🎖️ BATTLE PASS (${firestore.activeSeason})', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
        backgroundColor: const Color(0xFF0A0F1D),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: tiers.length,
        itemBuilder: (context, idx) {
          final t = tiers[idx];
          return CyberCard(
            padding: const EdgeInsets.all(12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('TIER ${t.tier} (${t.xpReq} XP)', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.amberAccent)),
                    const SizedBox(height: 4),
                    Text('Free: ${t.freeReward}', style: const TextStyle(fontSize: 11, color: Colors.white70)),
                    Text('VIP: ${t.vipReward}', style: const TextStyle(fontSize: 11, color: Colors.pinkAccent)),
                  ],
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                  onPressed: () {},
                  child: const Text('Claim'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
