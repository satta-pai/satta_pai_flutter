class UserModel {
  final String uid;
  final String email;
  final String username;
  final String ign;
  final String gameUid;
  final String playerId;
  final int spCoins;
  final bool isPremium;
  final bool isProPlus;
  final int premiumUntil;
  final int proPlusUntil;
  final bool hasVBadge;
  final bool isSuperAdmin;
  final bool isBanned;
  final String banReason;
  final int probationUntil;
  final String? freeSlotVoucher;
  final String? armoryTitle;
  final int bpBonusXp;
  final int lastBpDaily;
  final List<String> claimedMailIds;
  final List<String> deletedMailIds;
  final Map<String, dynamic>? savedSquad;
  final Map<String, dynamic>? banAppeal;

  UserModel({
    this.uid = '',
    required this.email,
    required this.username,
    required this.ign,
    required this.gameUid,
    required this.playerId,
    required this.spCoins,
    required this.isPremium,
    required this.isProPlus,
    required this.premiumUntil,
    required this.proPlusUntil,
    required this.hasVBadge,
    this.isSuperAdmin = false,
    required this.isBanned,
    required this.banReason,
    required this.probationUntil,
    this.freeSlotVoucher,
    this.armoryTitle,
    required this.bpBonusXp,
    required this.lastBpDaily,
    required this.claimedMailIds,
    required this.deletedMailIds,
    this.savedSquad,
    this.banAppeal,
  });

  factory UserModel.fromMap(Map<String, dynamic> map, String email, {String uid = '', bool isSuperAdmin = false}) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final premUntil = map['premiumUntil'] ?? 0;
    final plusUntil = map['proPlusUntil'] ?? 0;

    return UserModel(
      uid: uid,
      email: email.toLowerCase(),
      username: map['username'] ?? 'Player',
      ign: map['ign'] ?? 'No IGN',
      gameUid: map['gameUid'] ?? '',
      playerId: map['playerId'] ?? 'SP-0000',
      spCoins: map['spCoins'] ?? 0,
      isPremium: (map['isPremium'] == true) || (premUntil > now),
      isProPlus: (map['isProPlus'] == true) || (plusUntil > now),
      premiumUntil: premUntil,
      proPlusUntil: plusUntil,
      hasVBadge: map['hasVBadge'] == true,
      isSuperAdmin: isSuperAdmin,
      isBanned: map['isBanned'] == true,
      banReason: map['banReason'] ?? 'Fair Play Rule Violation',
      probationUntil: map['probationUntil'] ?? 0,
      freeSlotVoucher: map['freeSlotVoucher'],
      armoryTitle: map['armoryTitle'],
      bpBonusXp: map['bpBonusXp'] ?? 0,
      lastBpDaily: map['lastBpDaily'] ?? 0,
      claimedMailIds: List<String>.from(map['claimedMailIds'] ?? []),
      deletedMailIds: List<String>.from(map['deletedMailIds'] ?? []),
      savedSquad: map['savedSquad'] != null ? Map<String, dynamic>.from(map['savedSquad']) : null,
      banAppeal: map['banAppeal'] != null ? Map<String, dynamic>.from(map['banAppeal']) : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'username': username,
      'ign': ign,
      'gameUid': gameUid,
      'playerId': playerId,
      'spCoins': spCoins,
      'isPremium': isPremium,
      'isProPlus': isProPlus,
      'premiumUntil': premiumUntil,
      'proPlusUntil': proPlusUntil,
      'hasVBadge': hasVBadge,
      'isBanned': isBanned,
      'banReason': banReason,
      'probationUntil': probationUntil,
      'freeSlotVoucher': freeSlotVoucher,
      'armoryTitle': armoryTitle,
      'bpBonusXp': bpBonusXp,
      'lastBpDaily': lastBpDaily,
      'claimedMailIds': claimedMailIds,
      'deletedMailIds': deletedMailIds,
      'savedSquad': savedSquad,
      'banAppeal': banAppeal,
      'updatedAt': DateTime.now().millisecondsSinceEpoch,
    };
  }
}
