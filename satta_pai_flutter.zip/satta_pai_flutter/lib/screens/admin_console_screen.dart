import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../widgets/cyber_components.dart';

class AdminConsoleScreen extends StatelessWidget {
  const AdminConsoleScreen({super.key});

  void _toggleMaintenance(bool cur) async {
    await FirebaseFirestore.instance.collection('settings').doc('config').set({
      'maintenance': !cur,
    }, SetOptions(merge: true));
  }

  void _unbanUser(String email) async {
    await FirebaseFirestore.instance.collection('users').doc(email).update({
      'isBanned': false,
      'isPermanentBan': false,
      'probationUntil': 0,
      'banReason': '',
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🛡️ SUPER ADMIN CONSOLE', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
        backgroundColor: const Color(0xFF0A0F1D),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('⚙️ SYSTEM CONTROLS', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 10),
            CyberCard(
              child: ListTile(
                title: const Text('Maintenance Mode Toggle'),
                trailing: ElevatedButton(
                  onPressed: () => _toggleMaintenance(false),
                  child: const Text('Toggle'),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text('🚫 UNBAN PERMANENT BANNED USERS', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 10),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('users').where('isBanned', isEqualTo: true).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const CircularProgressIndicator();
                final docs = snapshot.data!.docs;
                if (docs.isEmpty) return const Text('No banned users.');

                return ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: docs.length,
                  itemBuilder: (context, idx) {
                    final d = docs[idx].data() as Map<String, dynamic>;
                    final email = d['email'] ?? docs[idx].id;
                    return CyberCard(
                      child: ListTile(
                        title: Text(email),
                        subtitle: Text(d['banReason'] ?? 'Violation'),
                        trailing: ElevatedButton(
                          onPressed: () => _unbanUser(email),
                          child: const Text('Unban'),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
