import 'package:audioplayers/audioplayers.dart';

class AudioSirenService {
  static final AudioPlayer _player = AudioPlayer();
  static bool isSirenEnabled = true;

  static Future<void> play10MinRoomSiren() async {
    if (!isSirenEnabled) return;
    try {
      await _player.stop();
      await _player.play(AssetSource('audio/siren_alert.mp3'));
    } catch (_) {}
  }

  static void toggleSiren() {
    isSirenEnabled = !isSirenEnabled;
  }
}
