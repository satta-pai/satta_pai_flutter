import 'dart:math';
import 'package:flutter/material.dart';

enum LiveThemeMode { none, anime, rain, winter, hacker, teddy, ghost, cat }

class AtmosphericThemeEngine extends StatefulWidget {
  final LiveThemeMode mode;
  final Widget child;

  const AtmosphericThemeEngine({super.key, required this.mode, required this.child});

  @override
  State<AtmosphericThemeEngine> createState() => _AtmosphericThemeEngineState();
}

class _AtmosphericThemeEngineState extends State<AtmosphericThemeEngine> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  final List<_ThemeParticle> _particles = [];
  final Random _random = Random();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 10))..repeat();
    _initParticles();
  }

  @override
  void didUpdateWidget(AtmosphericThemeEngine oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.mode != widget.mode) {
      _initParticles();
    }
  }

  void _initParticles() {
    _particles.clear();
    if (widget.mode == LiveThemeMode.none) return;

    final count = widget.mode == LiveThemeMode.hacker ? 26 : 20;
    for (int i = 0; i < count; i++) {
      _particles.add(
        _ThemeParticle(
          x: _random.nextDouble(),
          y: _random.nextDouble(),
          speed: 0.15 + _random.nextDouble() * 0.4,
          size: 8.0 + _random.nextDouble() * 14.0,
          opacity: 0.3 + _random.nextDouble() * 0.5,
          glyph: _resolveGlyph(widget.mode, i),
        ),
      );
    }
  }

  String _resolveGlyph(LiveThemeMode mode, int index) {
    switch (mode) {
      case LiveThemeMode.anime:
        const glyphs = ['🌸', '✨', '🗡️', '💮'];
        return glyphs[index % glyphs.length];
      case LiveThemeMode.winter:
        const glyphs = ['❄️', '❅', '❆', '•'];
        return glyphs[index % glyphs.length];
      case LiveThemeMode.teddy:
        const glyphs = ['🧸', '💖', '🎀', '✨'];
        return glyphs[index % glyphs.length];
      case LiveThemeMode.ghost:
        const glyphs = ['👻', '💀', '🩸', '👁️'];
        return glyphs[index % glyphs.length];
      case LiveThemeMode.cat:
        const glyphs = ['🐾', '🐱', '✨', '🍣'];
        return glyphs[index % glyphs.length];
      case LiveThemeMode.hacker:
        const glyphs = ['0', '1', 'X', '#', 'F', '9'];
        return glyphs[index % glyphs.length];
      case LiveThemeMode.rain:
      case LiveThemeMode.none:
        return '';
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.mode == LiveThemeMode.none) return widget.child;

    return Stack(
      children: [
        widget.child,
        Positioned.fill(
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, _) {
                return CustomPaint(
                  painter: _LiveThemePainter(
                    particles: _particles,
                    mode: widget.mode,
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

class _ThemeParticle {
  double x;
  double y;
  double speed;
  double size;
  double opacity;
  String glyph;

  _ThemeParticle({
    required this.x,
    required this.y,
    required this.speed,
    required this.size,
    required this.opacity,
    required this.glyph,
  });
}

class _LiveThemePainter extends CustomPainter {
  final List<_ThemeParticle> particles;
  final LiveThemeMode mode;

  _LiveThemePainter({required this.particles, required this.mode});

  @override
  void paint(Canvas canvas, Size size) {
    if (mode == LiveThemeMode.rain) {
      final paint = Paint()
        ..color = const Color(0xFF38BDF8).withOpacity(0.4)
        ..strokeWidth = 1.6
        ..strokeCap = StrokeCap.round;

      for (var p in particles) {
        p.y += (p.speed * 0.04);
        if (p.y > 1.05) {
          p.y = -0.05;
          p.x = Random().nextDouble();
        }
        final start = Offset(p.x * size.width, p.y * size.height);
        final end = Offset((p.x * size.width) - 4, (p.y * size.height) + 16);
        canvas.drawLine(start, end, paint);
      }
      return;
    }

    final textPainter = TextPainter(textDirection: TextDirection.ltr);

    for (var p in particles) {
      p.y += (p.speed * 0.01);
      if (p.y > 1.05) {
        p.y = -0.05;
        p.x = Random().nextDouble();
      }

      final position = Offset(p.x * size.width, p.y * size.height);
      if (mode == LiveThemeMode.hacker) {
        final textStyle = TextStyle(
          color: Colors.greenAccent.withOpacity(p.opacity),
          fontSize: p.size,
          fontFamily: 'monospace',
          fontWeight: FontWeight.bold,
        );
        textPainter.text = TextSpan(text: p.glyph, style: textStyle);
        textPainter.layout();
        textPainter.paint(canvas, position);
      } else {
        final textStyle = TextStyle(fontSize: p.size);
        textPainter.text = TextSpan(text: p.glyph, style: textStyle);
        textPainter.layout();
        textPainter.paint(canvas, position);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _LiveThemePainter oldDelegate) => true;
}
