class SystemMail {
  final String id;
  final String title;
  final String body;
  final String targetType; // 'all' or 'specific'
  final String targetUser;
  final String giftType; // 'coins', 'pro', 'plus', 'voucher', 'bp_xp', 'vbadge', 'none'
  final int giftAmount;
  final int createdAt;

  SystemMail({
    required this.id,
    required this.title,
    required this.body,
    required this.targetType,
    required this.targetUser,
    required this.giftType,
    required this.giftAmount,
    required this.createdAt,
  });

  bool get isExpired {
    final now = DateTime.now().millisecondsSinceEpoch;
    return (now - createdAt) > (14 * 24 * 60 * 60 * 1000); // 14-Day Auto Delete
  }

  int get daysRemaining {
    final now = DateTime.now().millisecondsSinceEpoch;
    final diff = (14 * 24 * 60 * 60 * 1000) - (now - createdAt);
    return (diff / (24 * 60 * 60 * 1000)).ceil().clamp(0, 14);
  }

  factory SystemMail.fromMap(Map<String, dynamic> map, String id) {
    return SystemMail(
      id: id,
      title: map['title'] ?? 'Official Arena Mail',
      body: map['body'] ?? '',
      targetType: map['targetType'] ?? 'all',
      targetUser: map['targetUser'] ?? 'all',
      giftType: map['giftType'] ?? 'none',
      giftAmount: map['giftAmount'] ?? 0,
      createdAt: map['createdAt'] ?? DateTime.now().millisecondsSinceEpoch,
    );
  }
}
