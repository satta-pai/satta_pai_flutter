import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_fonts/google_fonts.dart';

import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'widgets/live_theme_painters.dart';
import 'screens/home_screen.dart';
import 'screens/maintenance_ban_screens.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (_) {}

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => FirestoreService()),
      ],
      child: const SattaPaiApp(),
    ),
  );
}

class SattaPaiApp extends StatefulWidget {
  const SattaPaiApp({super.key});

  @override
  State<SattaPaiApp> createState() => _SattaPaiAppState();
}

class _SattaPaiAppState extends State<SattaPaiApp> {
  LiveThemeMode _activeTheme = LiveThemeMode.none;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Satta Pai Esports Arena',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF090D16),
        primaryColor: const Color(0xFF10B981),
        textTheme: GoogleFonts.rajdhaniTextTheme(ThemeData.dark().textTheme),
      ),
      home: Consumer2<AuthService, FirestoreService>(
        builder: (context, auth, firestore, _) {
          if (auth.isLoading) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator(color: Color(0xFF10B981))),
            );
          }

          final user = auth.currentUser;

          // 1. Enforce Maintenance Screen if active and user is not Super Admin
          if (firestore.isMaintenance && !user.isSuperAdmin) {
            return MaintenanceScreen(whatsappUrl: firestore.whatsappChannelUrl);
          }

          // 2. Enforce Hard Lockout if user is Banned
          if (user.isBanned) {
            return BanLockScreen(user: user);
          }

          // 3. Render High-Performance Gaming Core
          return AtmosphericThemeEngine(
            mode: _activeTheme,
            child: HomeScreen(
              onThemeChanged: (mode) => setState(() => _activeTheme = mode),
            ),
          );
        },
      ),
    );
  }
}
