class BattlePassTier {
  final int tier;
  final int xpReq;
  final String freeReward;
  final String vipReward;
  final int coins;
  final String title;

  const BattlePassTier({
    required this.tier,
    required this.xpReq,
    required this.freeReward,
    required this.vipReward,
    required this.coins,
    required this.title,
  });
}

class SeasonCatalog {
  static const Map<String, List<BattlePassTier>> seasons = {
    'S1': [
      BattlePassTier(tier: 1, xpReq: 0, freeReward: '🪙 +25 SP Coins', vipReward: '🎖️ Title: S1 CONTENDER', coins: 25, title: '🎖️ S1 CONTENDER'),
      BattlePassTier(tier: 5, xpReq: 150, freeReward: '🪙 +40 SP Coins', vipReward: '🔥 Title: ZONE SURVIVOR', coins: 40, title: '🔥 ZONE SURVIVOR'),
      BattlePassTier(tier: 10, xpReq: 350, freeReward: '🪙 +60 SP Coins', vipReward: '⚡ Title: RUSH COMMANDER', coins: 60, title: '⚡ RUSH COMMANDER'),
      BattlePassTier(tier: 20, xpReq: 700, freeReward: '🪙 +100 SP Coins', vipReward: '💎 Title: HEADSHOT MACHINE', coins: 100, title: '💎 HEADSHOT MACHINE'),
      BattlePassTier(tier: 35, xpReq: 1200, freeReward: '🪙 +150 SP Coins', vipReward: '🐉 Title: ARENA WARLORD', coins: 150, title: '🐉 ARENA WARLORD'),
      BattlePassTier(tier: 50, xpReq: 2000, freeReward: '🪙 +250 SP Coins', vipReward: '👑 Title: S1 BOOYAH EMPEROR', coins: 250, title: '👑 S1 BOOYAH EMPEROR'),
    ],
    'S2': [
      BattlePassTier(tier: 1, xpReq: 0, freeReward: '🪙 +30 SP Coins', vipReward: '🐉 Title: S2 CYBER ROOKIE', coins: 30, title: '🐉 S2 CYBER ROOKIE'),
      BattlePassTier(tier: 5, xpReq: 150, freeReward: '🪙 +50 SP Coins', vipReward: '⚡ Title: S2 NEON STRIKER', coins: 50, title: '⚡ S2 NEON STRIKER'),
      BattlePassTier(tier: 10, xpReq: 350, freeReward: '🪙 +75 SP Coins', vipReward: '🔥 Title: S2 PLASMA RUSHER', coins: 75, title: '🔥 S2 PLASMA RUSHER'),
      BattlePassTier(tier: 20, xpReq: 700, freeReward: '🪙 +120 SP Coins', vipReward: '💎 Title: S2 ONE-TAP KING', coins: 120, title: '💎 S2 ONE-TAP KING'),
      BattlePassTier(tier: 35, xpReq: 1200, freeReward: '🪙 +180 SP Coins', vipReward: '🐉 Title: S2 DRAGON IGL', coins: 180, title: '🐉 S2 DRAGON IGL'),
      BattlePassTier(tier: 50, xpReq: 2000, freeReward: '🪙 +300 SP Coins', vipReward: '👑 Title: S2 CYBER EMPEROR', coins: 300, title: '👑 S2 CYBER EMPEROR'),
    ],
    'S3': [
      BattlePassTier(tier: 1, xpReq: 0, freeReward: '🪙 +35 SP Coins', vipReward: '🥷 Title: S3 SHADOW GENIN', coins: 35, title: '🥷 S3 SHADOW GENIN'),
      BattlePassTier(tier: 5, xpReq: 150, freeReward: '🪙 +55 SP Coins', vipReward: '⚡ Title: S3 KUNAI MASTER', coins: 55, title: '⚡ S3 KUNAI MASTER'),
      BattlePassTier(tier: 10, xpReq: 350, freeReward: '🪙 +85 SP Coins', vipReward: '🔥 Title: S3 CRIMSON RONIN', coins: 85, title: '🔥 S3 CRIMSON RONIN'),
      BattlePassTier(tier: 20, xpReq: 700, freeReward: '🪙 +140 SP Coins', vipReward: '💎 Title: S3 AMATERASU SNIPER', coins: 140, title: '💎 S3 AMATERASU SNIPER'),
      BattlePassTier(tier: 35, xpReq: 1200, freeReward: '🪙 +200 SP Coins', vipReward: '🐉 Title: S3 SHADOW SHOGUN', coins: 200, title: '🐉 S3 SHADOW SHOGUN'),
      BattlePassTier(tier: 50, xpReq: 2000, freeReward: '🪙 +350 SP Coins', vipReward: '👑 Title: S3 HOKAGE SUPREME', coins: 350, title: '👑 S3 HOKAGE SUPREME'),
    ],
  };
}
