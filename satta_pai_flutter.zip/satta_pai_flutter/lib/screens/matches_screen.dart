import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../services/security_service.dart';
import '../models/match_model.dart';
import '../widgets/cyber_components.dart';

class MatchesScreen extends StatelessWidget {
  const MatchesScreen({super.key});

  void _openBookingDialog(BuildContext context, TournamentMatch match, String userEmail) {
    final teamNameCtrl = TextEditingController();
    final leaderCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final uid1Ctrl = TextEditingController();
    final uid2Ctrl = TextEditingController();
    final uid3Ctrl = TextEditingController();
    final uid4Ctrl = TextEditingController();
    final utrCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: const Color(0xFF111827),
          title: Text('Join ${match.title}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: teamNameCtrl, decoration: const InputDecoration(labelText: 'Team Name')),
                TextField(controller: leaderCtrl, decoration: const InputDecoration(labelText: 'Leader Name')),
                TextField(controller: phoneCtrl, decoration: const InputDecoration(labelText: '10-Digit Mobile')),
                TextField(controller: uid1Ctrl, decoration: const InputDecoration(labelText: 'Player 1 UID')),
                TextField(controller: uid2Ctrl, decoration: const InputDecoration(labelText: 'Player 2 UID')),
                TextField(controller: uid3Ctrl, decoration: const InputDecoration(labelText: 'Player 3 UID')),
                TextField(controller: uid4Ctrl, decoration: const InputDecoration(labelText: 'Player 4 UID')),
                if (match.type == 'paid')
                  TextField(controller: utrCtrl, decoration: const InputDecoration(labelText: '12-Digit UPI UTR')),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                final phone = phoneCtrl.text.trim();
                final uids = [uid1Ctrl.text, uid2Ctrl.text, uid3Ctrl.text, uid4Ctrl.text];

                if (!SecurityService.isValidPhone(phone)) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invalid 10-digit mobile number!')));
                  return;
                }

                final uidVal = SecurityService.validateSquadUids(uids);
                if (!uidVal['valid']) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(uidVal['msg'])));
                  return;
                }

                if (match.type == 'paid') {
                  final utrVal = SecurityService.validateUtr(utrCtrl.text.trim());
                  if (!utrVal['valid']) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(utrVal['reason'])));
                    return;
                  }
                }

                // Register Squad
                final regRef = FirebaseFirestore.instance.collection('registrations').doc();
                final privRef = FirebaseFirestore.instance.collection('registrations_private').doc(regRef.id);

                await FirebaseFirestore.instance.runTransaction((tx) async {
                  tx.set(regRef, {
                    'teamName': teamNameCtrl.text.trim().toUpperCase(),
                    'leaderName': leaderCtrl.text.trim(),
                    'gameUid': uids[0],
                    'member2Uid': uids[1],
                    'member3Uid': uids[2],
                    'member4Uid': uids[3],
                    'matchId': match.id,
                    'slotGroup': 'TEAM A',
                    'isVerified': match.type == 'free',
                    'createdAt': DateTime.now().millisecondsSinceEpoch,
                  });

                  tx.set(privRef, {
                    'phoneNumber': phone,
                    'transitionId': utrCtrl.text.trim(),
                    'userEmail': userEmail,
                  });

                  tx.update(FirebaseFirestore.instance.collection('matches').doc(match.id), {
                    'currentSlots': FieldValue.increment(1),
                  });
                });

                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('✅ Squad Successfully Registered!')));
              },
              child: const Text('Submit Slot'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    final firestore = Provider.of<FirestoreService>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('🎮 TOURNAMENT LOBBIES', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
        backgroundColor: const Color(0xFF0A0F1D),
      ),
      body: StreamBuilder<List<TournamentMatch>>(
        stream: firestore.getMatchesStream(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final matches = snapshot.data!;

          if (matches.isEmpty) return const Center(child: Text('No active tournaments found.'));

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: matches.length,
            itemBuilder: (context, idx) {
              final m = matches[idx];
              return CyberCard(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(m.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        Text('₹${m.prizePool} PRIZE', style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.amberAccent)),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text('${m.map} • ${m.time} • Slots: ${m.currentSlots}/${m.slots}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF10B981),
                        minimumSize: const Size(double.infinity, 40),
                      ),
                      onPressed: () => _openBookingDialog(context, m, auth.currentUser.email),
                      child: Text(m.type == 'free' ? 'JOIN FREE SLOT' : 'JOIN SLOT (₹${m.entryFee})'),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
