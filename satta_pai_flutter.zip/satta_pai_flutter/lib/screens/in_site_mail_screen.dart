import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../models/mail_model.dart';
import '../widgets/cyber_components.dart';

class InSiteMailScreen extends StatelessWidget {
  const InSiteMailScreen({super.key});

  void _claimGift(BuildContext context, SystemMail mail, String userEmail) async {
    final userRef = FirebaseFirestore.instance.collection('users').doc(userEmail);

    await FirebaseFirestore.instance.runTransaction((tx) async {
      final snap = await tx.get(userRef);
      if (!snap.exists) return;

      final data = snap.data()!;
      final claimed = List<String>.from(data['claimedMailIds'] ?? []);
      if (claimed.contains(mail.id)) return;

      claimed.add(mail.id);
      final updates = <String, dynamic>{'claimedMailIds': claimed};

      if (mail.giftType == 'coins') {
        updates['spCoins'] = (data['spCoins'] ?? 0) + mail.giftAmount;
      } else if (mail.giftType == 'voucher') {
        updates['freeSlotVoucher'] = 'FREE-SLOT-${(mail.id.hashCode.abs() % 9000 + 1000)}';
      }

      tx.update(userRef, updates);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('🎉 Claimed Gift: ${mail.title}!')),
    );
  }

  void _deleteMail(String mailId, String userEmail) async {
    await FirebaseFirestore.instance.collection('users').doc(userEmail).update({
      'deletedMailIds': FieldValue.arrayUnion([mailId]),
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    final firestore = Provider.of<FirestoreService>(context);
    final user = auth.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('📬 ARENA SYSTEM MAILBOX', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
        backgroundColor: const Color(0xFF0A0F1D),
      ),
      body: StreamBuilder<List<SystemMail>>(
        stream: firestore.getApplicableMailsStream(user.email, user.playerId),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final mails = snapshot.data!.where((m) => !user.deletedMailIds.contains(m.id)).toList();

          if (mails.isEmpty) {
            return const Center(child: Text('📭 No active system mails. Check back soon!'));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: mails.length,
            itemBuilder: (context, idx) {
              final m = mails[idx];
              final isClaimed = user.claimedMailIds.contains(m.id);

              return CyberCard(
                padding: const EdgeInsets.all(14),
                borderColor: isClaimed ? Colors.white12 : Colors.amber.withOpacity(0.5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(m.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.white)),
                        Text('⏳ ${m.daysRemaining}d left', style: const TextStyle(fontSize: 10, color: Colors.amberAccent)),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(m.body, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        if (m.giftType != 'none')
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isClaimed ? Colors.grey : Colors.emerald,
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                            ),
                            onPressed: isClaimed ? null : () => _claimGift(context, m, user.email),
                            child: Text(isClaimed ? 'Claimed ✓' : '🎁 Claim Gift'),
                          )
                        else
                          const SizedBox.shrink(),
                        IconButton(
                          icon: const Icon(Icons.delete_outline, size: 18, color: Colors.redAccent),
                          onPressed: () => _deleteMail(m.id, user.email),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
