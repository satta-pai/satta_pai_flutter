import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Color(0xFF05070B),
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF05070B),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const SattaPaiHybridApp());
}

class SattaPaiHybridApp extends StatelessWidget {
  const SattaPaiHybridApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Satta Pai',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF05070B),
        primaryColor: const Color(0xFF00FFFF),
      ),
      home: const SattaPaiArenaShell(),
    );
  }
}

class SattaPaiArenaShell extends StatefulWidget {
  const SattaPaiArenaShell({super.key});

  @override
  State<SattaPaiArenaShell> createState() => _SattaPaiArenaShellState();
}

class _SattaPaiArenaShellState extends State<SattaPaiArenaShell> {
  WebViewController? _controller;
  HttpServer? _localServer;
  bool _isReady = false;

  @override
  void initState() {
    super.initState();
    _startLocalArenaEngine();
  }

  Future<void> _startLocalArenaEngine() async {
    try {
      final String htmlContent = await rootBundle.loadString('assets/www/index.html');

      try {
        _localServer = await HttpServer.bind(InternetAddress.loopbackIPv4, 8765, shared: true);
      } catch (_) {
        _localServer = await HttpServer.bind(InternetAddress.loopbackIPv4, 0, shared: true);
      }
      final int port = _localServer!.port;

      _localServer!.listen((HttpRequest request) async {
        request.response.headers.contentType = ContentType.html;
        request.response.headers.add('Access-Control-Allow-Origin', '*');
        request.response.write(htmlContent);
        await request.response.close();
      });

      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFF05070B))
        ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
        )
        ..setNavigationDelegate(
          NavigationDelegate(
            onNavigationRequest: (NavigationRequest request) {
              final String url = request.url;
              if (url.startsWith('intent://') ||
                  url.startsWith('freefire://') ||
                  url.startsWith('freefiremax://') ||
                  url.startsWith('upi://') ||
                  url.startsWith('whatsapp://') ||
                  url.startsWith('tg://') ||
                  url.startsWith('mailto:') ||
                  url.contains('whatsapp.com/channel/') ||
                  url.contains('t.me/') ||
                  url.contains('play.google.com/store')) {
                _launchExternalAppUrl(url);
                return NavigationDecision.prevent;
              }
              return NavigationDecision.navigate;
            },
          ),
        )
        ..loadRequest(Uri.parse('http://localhost:$port/index.html'));

      if (mounted) {
        setState(() {
          _controller = controller;
          _isReady = true;
        });
      }
    } catch (e) {
      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFF05070B))
        ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
        )
        ..loadRequest(Uri.parse('https://satta-pai.github.io/'));
      if (mounted) {
        setState(() {
          _controller = controller;
          _isReady = true;
        });
      }
    }
  }

  Future<void> _launchExternalAppUrl(String url) async {
    try {
      if (url.startsWith('intent://')) {
        final pkgMatch = RegExp(r'package=([a-zA-Z0-9._]+)').firstMatch(url);
        if (pkgMatch != null) {
          final pkg = pkgMatch.group(1)!;
          final marketUri = Uri.parse('market://details?id=$pkg');
          if (await canLaunchUrl(marketUri)) {
            await launchUrl(marketUri, mode: LaunchMode.externalApplication);
            return;
          }
        }
        return;
      }
      final uri = Uri.parse(url);
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  void dispose() {
    _localServer?.close(force: true);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_controller != null && await _controller!.canGoBack()) {
          await _controller!.goBack();
          return false;
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF05070B),
        body: SafeArea(
          child: _isReady && _controller != null
              ? WebViewWidget(controller: _controller!)
              : Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.asset(
                          'assets/www/logo.png',
                          width: 96,
                          height: 96,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(height: 18),
                      const CircularProgressIndicator(color: Color(0xFF00FFFF)),
                      const SizedBox(height: 12),
                      const Text(
                        'SATTA PAI ARENA',
                        style: TextStyle(
                          color: Color(0xFF00FFFF),
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}
