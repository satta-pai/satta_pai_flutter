import 'package:flutter/material.dart';

class CyberCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? borderColor;
  final Color? backgroundColor;

  const CyberCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(12),
    this.borderColor,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: backgroundColor ?? const Color(0xFF111827),
        border: Border.all(color: borderColor ?? Colors.white12),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }
}

class VBadgePill extends StatelessWidget {
  const VBadgePill({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFDE047), Color(0xFFEA580C)]),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: const Color(0xFFFEF08A)),
      ),
      child: const Text(
        '✔️ V',
        style: TextStyle(
          fontSize: 8.5,
          fontWeight: FontWeight.w900,
          color: Colors.black,
        ),
      ),
    );
  }
}

class VipBadgePill extends StatelessWidget {
  final bool isProPlus;

  const VipBadgePill({super.key, this.isProPlus = false});

  @override
  Widget build(BuildContext context) {
    if (isProPlus) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFFFBBF24), Color(0xFFEC4899)]),
          borderRadius: BorderRadius.circular(10),
        ),
        child: const Text('👑 PRO+', style: TextStyle(fontSize: 8.5, fontWeight: FontWeight.w900, color: Colors.black)),
      );
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: const Color(0xFF10B981).withOpacity(0.2),
        border: Border.all(color: const Color(0xFF10B981)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Text('⭐ PRO', style: TextStyle(fontSize: 8.5, fontWeight: FontWeight.bold, color: Color(0xFF10B981))),
    );
  }
}
