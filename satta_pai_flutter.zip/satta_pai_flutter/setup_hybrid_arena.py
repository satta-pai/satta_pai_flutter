import os, re, shutil

print("=== SATTA PAI HYBRID ARENA IN-PLACE CONFIGURER ===")

# 1. Copy assets/www/index.html, assets/www/logo.png, and lib/main.dart
os.makedirs("assets/www", exist_ok=True)
if os.path.exists("/tmp/sp_bundle/assets/www/index.html"):
    shutil.copy2("/tmp/sp_bundle/assets/www/index.html", "assets/www/index.html")
if os.path.exists("/tmp/sp_bundle/assets/www/logo.png"):
    shutil.copy2("/tmp/sp_bundle/assets/www/logo.png", "assets/www/logo.png")
if os.path.exists("/tmp/sp_bundle/lib/main.dart"):
    os.makedirs("lib", exist_ok=True)
    shutil.copy2("/tmp/sp_bundle/lib/main.dart", "lib/main.dart")

# 2. Replace Android Launcher Icons (remove adaptive XML so our custom PNG logo is used on all Android versions)
shutil.rmtree("android/app/src/main/res/mipmap-anydpi-v26", ignore_errors=True)
shutil.rmtree("android/app/src/main/res/mipmap-anydpi", ignore_errors=True)
icons_root = "/tmp/sp_bundle/android/app/src/main/res"
if os.path.exists(icons_root):
    for folder in os.listdir(icons_root):
        src_dir = os.path.join(icons_root, folder)
        dst_dir = os.path.join("android/app/src/main/res", folder)
        if os.path.isdir(src_dir):
            os.makedirs(dst_dir, exist_ok=True)
            for fn in os.listdir(src_dir):
                shutil.copy2(os.path.join(src_dir, fn), os.path.join(dst_dir, fn))

# 3. Safely register assets/www/index.html and assets/www/logo.png in pubspec.yaml
with open("pubspec.yaml", "r", encoding="utf-8") as f:
    pub = f.read()

# Remove commented-out assets lines so we don't duplicate
if "assets/www/index.html" not in pub:
    pub = pub.replace(
        "  uses-material-design: true",
        "  uses-material-design: true\n  assets:\n    - assets/www/index.html\n    - assets/www/logo.png"
    )
with open("pubspec.yaml", "w", encoding="utf-8") as f:
    f.write(pub)

# 4. Safely patch android/app/src/main/AndroidManifest.xml IN-PLACE (preserves generated namespace & MainActivity!)
manifest_path = "android/app/src/main/AndroidManifest.xml"
if os.path.exists(manifest_path):
    with open(manifest_path, "r", encoding="utf-8") as f:
        mf = f.read()

    # Add INTERNET permission & package visibility queries if not present
    perms_and_queries = '''
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <queries>
        <package android:name="com.dts.freefiremax" />
        <package android:name="com.dts.freefireth" />
        <package android:name="com.garena.game.ffi" />
        <package android:name="com.whatsapp" />
        <package android:name="org.telegram.messenger" />
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="upi" />
        </intent>
    </queries>
'''
    if "android.permission.INTERNET" not in mf:
        mf = mf.replace("<application", perms_and_queries + "\n    <application", 1)

    # Set App Display Name to "Satta Pai"
    mf = re.sub(r'android:label="[^"]*"', 'android:label="Satta Pai"', mf)

    # Enable cleartext traffic for localhost loopback engine
    if "usesCleartextTraffic" not in mf:
        mf = mf.replace("<application", '<application\n        android:usesCleartextTraffic="true"', 1)

    with open(manifest_path, "w", encoding="utf-8") as f:
        f.write(mf)

# 5. Ensure minSdk is at least 21 in android/app/build.gradle or build.gradle.kts
for gradle_file in ["android/app/build.gradle", "android/app/build.gradle.kts"]:
    if os.path.exists(gradle_file):
        with open(gradle_file, "r", encoding="utf-8") as f:
            g = f.read()
        g = g.replace("minSdkVersion flutter.minSdkVersion", "minSdkVersion 21")
        g = g.replace("minSdk = flutter.minSdkVersion", "minSdk = 21")
        with open(gradle_file, "w", encoding="utf-8") as f:
            f.write(g)

print("=== SATTA PAI HYBRID ARENA CONFIGURED SUCCESSFULLY ===")
