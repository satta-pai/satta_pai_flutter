import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import '../services/security_service.dart';

class MaintenanceScreen extends StatelessWidget {
  final String whatsappUrl;

  const MaintenanceScreen({
    super.key,
    this.whatsappUrl = 'https://whatsapp.com/channel/0029VbE978BDeON879ZJiS3z',
  });

  void _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF09090B),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFF121218),
              border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.4), width: 2),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.amber.withOpacity(0.4)),
                  ),
                  child: const Text('⚡ SYSTEM MAINTENANCE MODE', style: TextStyle(color: Colors.amberAccent, fontSize: 11, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 16),
                const Text('🔧', style: TextStyle(fontSize: 48)),
                const SizedBox(height: 12),
                const Text('Satta Pai Arena Upgrades', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Colors.white)),
                const SizedBox(height: 8),
                const Text(
                  'Our engineering team is actively upgrading tournament custom rooms and calibrating matchmaking firewalls.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF10B981),
                    minimumSize: const Size(double.infinity, 48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: const Text('📢'),
                  label: const Text('Join WhatsApp Channel', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                  onPressed: () => _launchUrl(whatsappUrl),
                ),
                const SizedBox(height: 10),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0284C7),
                    minimumSize: const Size(double.infinity, 48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: const Text('✈️'),
                  label: const Text('Emergency Support (@CHELLAM_STORE)', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                  onPressed: () => _launchUrl('https://t.me/CHELLAM_STORE'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class BanLockScreen extends StatefulWidget {
  final UserModel user;

  const BanLockScreen({super.key, required this.user});

  @override
  State<BanLockScreen> createState() => _BanLockScreenState();
}

class _BanLockScreenState extends State<BanLockScreen> {
  final TextEditingController _appealController = TextEditingController();
  bool _isSubmitting = false;

  void _submitAppeal() async {
    final text = SecurityService.sanitizeInput(_appealController.text, maxLength: 500);
    if (text.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please write a detailed explanation (min 10 characters)!')),
      );
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      await FirebaseFirestore.instance.collection('users').doc(widget.user.email).set({
        'banAppeal': {
          'appealText': text,
          'submittedAt': DateTime.now().millisecondsSinceEpoch,
          'status': 'pending',
          'playerEmail': widget.user.email,
        }
      }, SetOptions(merge: true));

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Ban Appeal Submitted to Super Admin!')),
      );
      _appealController.clear();
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to submit appeal. Please try again.')),
      );
    } finally {
      setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF180C10),
              border: Border.all(color: Colors.redAccent.withOpacity(0.6), width: 2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('🚫', style: TextStyle(fontSize: 48)),
                const SizedBox(height: 10),
                const Text('ACCOUNT BANNED & LOCKED', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.white)),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Account: ${widget.user.email}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                      const SizedBox(height: 4),
                      Text('Reason: ${widget.user.banReason}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.redAccent)),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Submit Ban Appeal (Customer Care)', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.cyanAccent)),
                const SizedBox(height: 8),
                TextField(
                  controller: _appealController,
                  maxLines: 3,
                  style: const TextStyle(fontSize: 12),
                  decoration: InputDecoration(
                    hintText: 'Explain why your account should be unbanned...',
                    filled: true,
                    fillColor: Colors.black26,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.emerald,
                    minimumSize: const Size(double.infinity, 44),
                  ),
                  onPressed: _isSubmitting ? null : _submitAppeal,
                  child: Text(_isSubmitting ? 'Submitting...' : 'Submit Appeal to Super Admin'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
