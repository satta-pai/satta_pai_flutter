# Satta Pai Free Fire Tournament Arena - Flutter Production Client

## Quick Start (Android Studio / VS Code / Spck Editor)

1. **Install Dependencies:**
   ```bash
   flutter pub get
   ```

2. **Run on Android / Web:**
   ```bash
   flutter run -d chrome # For Web
   flutter run # For Android Phone
   ```

3. **Build Security-Hardened Obfuscated APK:**
   ```bash
   flutter build apk --release --obfuscate --split-debug-info=build/app/outputs/symbols
   ```

4. **Features Included:**
   - 7 Atmospheric Live Theme Painters
   - 1-Click Game Launchers (MAX, Standard, India)
   - Real-Time Room Keys & 10-Min Siren
   - In-Site Mailbox (14-Day Auto-Delete)
   - Multi-Season Battle Pass (S1, S2, S3)
   - Super Admin & Host Console
