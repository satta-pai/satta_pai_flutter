import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../services/game_launcher_service.dart';
import '../widgets/live_theme_painters.dart';
import '../widgets/cyber_components.dart';
import 'matches_screen.dart';
import 'spin_wheel_screen.dart';
import 'in_site_mail_screen.dart';
import 'battle_pass_screen.dart';
import 'admin_console_screen.dart';

class HomeScreen extends StatelessWidget {
  final Function(LiveThemeMode) onThemeChanged;

  const HomeScreen({super.key, required this.onThemeChanged});

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    final firestore = Provider.of<FirestoreService>(context);
    final user = auth.currentUser;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0F1D),
        elevation: 0,
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF10B981), Color(0xFFF59E0B)]),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Center(
                child: Text('SP', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.black)),
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(user.username, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    if (user.hasVBadge) ...[
                      const SizedBox(width: 4),
                      const VBadgePill(),
                    ],
                  ],
                ),
                Text(
                  user.isProPlus ? '👑 PRO PLUS MEMBER' : (user.isPremium ? '⭐ PRO MEMBER' : '🎮 CONTENDER'),
                  style: TextStyle(
                    fontSize: 9,
                    color: user.isProPlus ? const Color(0xFFFBBF24) : const Color(0xFF10B981),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          // SP Coins Counter Button
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SpinWheelScreen())),
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 10),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.15),
                border: Border.all(color: Colors.amber.withOpacity(0.4)),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  const Text('🪙', style: TextStyle(fontSize: 12)),
                  const SizedBox(width: 4),
                  Text('${user.spCoins}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.amberAccent)),
                ],
              ),
            ),
          ),
          const SizedBox(width: 6),

          // In-Site Mailbox
          IconButton(
            icon: Stack(
              children: [
                const Icon(FontAwesomeIcons.envelope, size: 20),
                StreamBuilder<int>(
                  stream: firestore.getUnreadMailCountStream(user.email, user.playerId, user.claimedMailIds, user.deletedMailIds),
                  builder: (context, snapshot) {
                    final count = snapshot.data ?? 0;
                    if (count == 0) return const SizedBox.shrink();
                    return Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle),
                        child: Text('$count', style: const TextStyle(fontSize: 8, fontWeight: FontWeight.bold)),
                      ),
                    );
                  },
                ),
              ],
            ),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InSiteMailScreen())),
          ),

          // Super Admin Access Portal
          if (user.isSuperAdmin)
            IconButton(
              icon: const Icon(FontAwesomeIcons.shieldHalved, color: Colors.amberAccent),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminConsoleScreen())),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🚀 Free Fire 1-Tap Launchers
            const Text('🚀 1-TAP FREE FIRE LAUNCHERS', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: Colors.grey)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.withOpacity(0.2)),
                    onPressed: () => GameLauncherService.launchGame(edition: FreeFireEdition.max),
                    child: const Text('FF MAX', style: TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.teal.withOpacity(0.2)),
                    onPressed: () => GameLauncherService.launchGame(edition: FreeFireEdition.india),
                    child: const Text('FF INDIA', style: TextStyle(color: Colors.tealAccent, fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.amber.withOpacity(0.2)),
                    onPressed: () => GameLauncherService.launchGame(edition: FreeFireEdition.standard),
                    child: const Text('STANDARD', style: TextStyle(color: Colors.amberAccent, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Navigation Grid
            GridView.count(
              crossAxisCount: MediaQuery.of(context).size.width > 600 ? 4 : 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              children: [
                _HomeNavCard(
                  icon: FontAwesomeIcons.trophy,
                  title: 'TOURNAMENTS',
                  subtitle: 'Daily BR / CS Lobbies',
                  color: Colors.emerald,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MatchesScreen())),
                ),
                _HomeNavCard(
                  icon: FontAwesomeIcons.dharmachakra,
                  title: 'LUCKY SPIN',
                  subtitle: 'Daily Free SP Coins',
                  color: Colors.amber,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SpinWheelScreen())),
                ),
                _HomeNavCard(
                  icon: FontAwesomeIcons.medal,
                  title: 'BATTLE PASS',
                  subtitle: 'Season Level Rewards',
                  color: Colors.purple,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BattlePassScreen())),
                ),
                _HomeNavCard(
                  icon: FontAwesomeIcons.palette,
                  title: 'ATMOSPHERE',
                  subtitle: '7 Live Cyber Themes',
                  color: Colors.pinkAccent,
                  onTap: () => _showThemePicker(context, onThemeChanged),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showThemePicker(BuildContext context, Function(LiveThemeMode) onThemeChanged) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111827),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return Wrap(
          children: LiveThemeMode.values.map((mode) {
            return ListTile(
              title: Text(mode.name.toUpperCase()),
              onTap: () {
                onThemeChanged(mode);
                Navigator.pop(context);
              },
            );
          }).toList(),
        );
      },
    );
  }
}

class _HomeNavCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final MaterialColor color;
  final VoidCallback onTap;

  const _HomeNavCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: CyberCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 26),
            const Spacer(),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
            Text(subtitle, style: const TextStyle(fontSize: 10, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
