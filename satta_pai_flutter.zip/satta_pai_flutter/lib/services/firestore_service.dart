import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/match_model.dart';
import '../models/team_model.dart';
import '../models/mail_model.dart';
import '../models/clan_model.dart';

class FirestoreService extends ChangeNotifier {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  bool isMaintenance = false;
  String whatsappChannelUrl = 'https://whatsapp.com/channel/0029VbE978BDeON879ZJiS3z';
  String activeSeason = 'S1';
  bool vipUpiEnabled = true;
  List<String> authorizedAdmins = [];
  List<String> authorizedHosts = [];
  List<String> authorizedVBadges = [];

  FirestoreService() {
    _listenToSettings();
  }

  void _listenToSettings() {
    _db.collection('settings').doc('config').snapshots().listen((snap) {
      if (snap.exists) {
        final d = snap.data()!;
        isMaintenance = d['maintenance'] == true;
        whatsappChannelUrl = d['whatsappChannelUrl'] ?? whatsappChannelUrl;
        activeSeason = d['activeSeason'] ?? 'S1';
        vipUpiEnabled = d['vipUpiEnabled'] != false;
        authorizedAdmins = List<String>.from(d['admins_list'] ?? []).map((e) => e.toLowerCase()).toList();
        authorizedHosts = List<String>.from(d['hosts_list'] ?? []).map((e) => e.toLowerCase()).toList();
        authorizedVBadges = List<String>.from(d['vbadge_list'] ?? []).map((e) => e.toLowerCase()).toList();
        notifyListeners();
      }
    });
  }

  // --- Real-Time Stream Listeners ---

  Stream<List<TournamentMatch>> getMatchesStream() {
    return _db.collection('matches').orderBy('createdAt', descending: true).snapshots().map(
      (snap) => snap.docs.map((doc) => TournamentMatch.fromMap(doc.data(), doc.id)).toList(),
    );
  }

  Stream<List<TournamentMatch>> getUserRegisteredMatches(String email) {
    return _db.collection('matches').snapshots().map(
      (snap) => snap.docs.map((doc) => TournamentMatch.fromMap(doc.data(), doc.id)).toList(),
    );
  }

  Stream<List<SystemMail>> getApplicableMailsStream(String email, String playerId) {
    return _db.collection('site_mails').orderBy('createdAt', descending: true).snapshots().map((snap) {
      return snap.docs
          .map((doc) => SystemMail.fromMap(doc.data(), doc.id))
          .where((m) => !m.isExpired && (m.targetType == 'all' || m.targetUser.toLowerCase() == email.toLowerCase() || m.targetUser.toUpperCase() == playerId.toUpperCase()))
          .toList();
    });
  }

  Stream<int> getUnreadMailCountStream(String email, String playerId, List<String> claimedIds, List<String> deletedIds) {
    return getApplicableMailsStream(email, playerId).map((mails) {
      return mails.where((m) => !claimedIds.contains(m.id) && !deletedIds.contains(m.id)).length;
    });
  }

  Stream<List<ClanModel>> getClansStream() {
    return _db.collection('clans').orderBy('points', descending: true).snapshots().map(
      (snap) => snap.docs.map((doc) => ClanModel.fromMap(doc.data(), doc.id)).toList(),
    );
  }
}
