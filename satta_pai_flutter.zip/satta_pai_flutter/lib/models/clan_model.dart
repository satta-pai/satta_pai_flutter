class ClanModel {
  final String id;
  final String tag;
  final String name;
  final String motto;
  final String leader;
  final int membersCount;
  final int points;

  ClanModel({
    required this.id,
    required this.tag,
    required this.name,
    required this.motto,
    required this.leader,
    required this.membersCount,
    required this.points,
  });

  factory ClanModel.fromMap(Map<String, dynamic> map, String id) {
    return ClanModel(
      id: id,
      tag: map['tag'] ?? 'SP',
      name: map['name'] ?? 'Satta Pai Clan',
      motto: map['motto'] ?? 'Booyah Squad',
      leader: map['leader'] ?? 'Leader',
      membersCount: map['membersCount'] ?? 1,
      points: map['points'] ?? 250,
    );
  }
}
