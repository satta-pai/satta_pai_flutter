import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/auth_service.dart';
import '../widgets/cyber_components.dart';

class SpinWheelScreen extends StatefulWidget {
  const SpinWheelScreen({super.key});

  @override
  State<SpinWheelScreen> createState() => _SpinWheelScreenState();
}

class _SpinWheelScreenState extends State<SpinWheelScreen> with SingleTickerProviderStateMixin {
  late AnimationController _wheelController;
  bool _isSpinning = false;
  final List<int> _rewards = [10, 20, 30, 50, 75, 100];

  @override
  void initState() {
    super.initState();
    _wheelController = AnimationController(vsync: this, duration: const Duration(seconds: 4));
  }

  void _spin(String email, int curCoins) async {
    if (_isSpinning) return;
    setState(() => _isSpinning = true);

    final randomIdx = Random().nextInt(_rewards.length);
    final winCoins = _rewards[randomIdx];

    _wheelController.reset();
    _wheelController.forward().then((_) async {
      await FirebaseFirestore.instance.collection('users').doc(email).update({
        'spCoins': curCoins + winCoins,
        'lastDailySpin': DateTime.now().millisecondsSinceEpoch,
      });

      setState(() => _isSpinning = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('🎉 Congratulations! You won +$winCoins SP Coins!')),
        );
      }
    });
  }

  @override
  void dispose() {
    _wheelController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);
    final user = auth.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('🎰 24H LUCKY SPIN & SP COINS', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        backgroundColor: const Color(0xFF0A0F1D),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Available Balance: ${user.spCoins} 🪙', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.amberAccent)),
              const SizedBox(height: 30),
              RotationTransition(
                turns: _wheelController,
                child: Container(
                  width: 220,
                  height: 220,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.amberAccent, width: 4),
                    gradient: const RadialGradient(colors: [Colors.purple, Colors.black87]),
                  ),
                  child: const Center(
                    child: Text('🎡 SPIN', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 24, color: Colors.white)),
                  ),
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  minimumSize: const Size(200, 48),
                ),
                onPressed: _isSpinning ? null : () => _spin(user.email, user.spCoins),
                child: Text(_isSpinning ? 'SPINNING...' : 'LUCKY SPIN (+10 to +100)', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
