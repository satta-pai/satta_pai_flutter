/**
 * 🛡️ SATTA PAI TOURNAMENT ARENA — SECURE BACKEND AI PROXY (Cloudflare Worker)
 * --------------------------------------------------------------------------
 * Why use this?
 * - Keeps your GEMINI_API_KEY 100% hidden on Cloudflare's free backend server.
 * - Blocks unauthorized websites from stealing your AI quota (CORS Origin Lock).
 * - Free Tier: 100,000 requests/day on Cloudflare Workers (No PC needed!).
 *
 * Setup on Mobile Phone (2 Minutes):
 * 1. Go to https://dash.cloudflare.com -> Sign up / Log in -> Workers & Pages -> Create Worker.
 * 2. Paste this code and click "Deploy".
 * 3. Go to Worker Settings -> Variables and Secrets -> Add Secret:
 *    Variable Name: GEMINI_API_KEY
 *    Value: <Your_Gemini_API_Key>
 * 4. Copy your Worker URL (e.g., https://satta-pai-ai.yourname.workers.dev)
 *    and paste it into the Super Admin Console -> AI Key Vault input box!
 */

const ALLOWED_ORIGINS = [
  "https://satta-pai.github.io",
  "http://localhost",
  "http://127.0.0.1"
];

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const isAllowed = !origin || ALLOWED_ORIGINS.some(o => origin.startsWith(o));

    const corsHeaders = {
      "Access-Control-Allow-Origin": isAllowed ? (origin || "*") : "https://satta-pai.github.io",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    if (!isAllowed) {
      return new Response(JSON.stringify({ error: "Unauthorized domain blocked by Satta Pai Security" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    if (request.method !== "POST") {
      return new Response(JSON.stringify({ status: "Satta Pai AI Backend Active" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    try {
      const { query, tier } = await request.json();
      if (!query || typeof query !== "string") {
        return new Response(JSON.stringify({ error: "Missing query" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }

      const apiKey = env.GEMINI_API_KEY;
      if (!apiKey) {
        return new Response(JSON.stringify({ error: "GEMINI_API_KEY secret not set in Worker Settings" }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }

      const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
      const sysPrompt = "You are Satta Pai AI, the official Free Fire Tournament Arena Assistant. Reply concisely in helpful Tanglish or English. User Tier: " + (tier || "free");

      const resp = await fetch(geminiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${sysPrompt}\n\nUser Question: ${query.slice(0, 600)}` }] }]
        })
      });

      const data = await resp.json();
      const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Ask me about tournaments, room IDs, or sensitivity!";

      return new Response(JSON.stringify({ reply }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    } catch (err) {
      return new Response(JSON.stringify({ error: "Backend error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }
  }
};
