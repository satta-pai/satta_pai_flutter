import 'dart:convert';
import 'package:crypto/crypto.dart';

class SecurityService {
  static final RegExp _phoneRegex = RegExp(r'^[6-9][0-9]{9}$');
  static final RegExp _uidRegex = RegExp(r'^[0-9]{7,13}$');
  static final RegExp _utrRegex = RegExp(r'^[0-9]{12}$');
  static final RegExp _voucherRegex = RegExp(r'^FREE-SLOT-[A-Z0-9]{4,8}$');
  static final RegExp _scriptInjectionRegex = RegExp(
    r'<[^>]*>|javascript:|onerror=|onload=|script',
    caseSensitive: false,
  );

  /// Sanitize text inputs against Cross-Site Scripting (XSS) and injection vectors
  static String sanitizeInput(String input, {int maxLength = 255}) {
    String clean = input.replaceAll(_scriptInjectionRegex, '');
    clean = clean.replaceAll(RegExp(r'[<>"\'/\\;]'), '');
    if (clean.length > maxLength) {
      clean = clean.substring(0, maxLength);
    }
    return clean.trim();
  }

  /// 10-Digit Mobile Phone Validation (Indian Telecom Standards)
  static bool isValidPhone(String phone) {
    return _phoneRegex.hasMatch(phone.trim());
  }

  /// 7-13 Digit Free Fire Numeric UID Validation
  static bool isValidGameUid(String uid) {
    return _uidRegex.hasMatch(uid.trim());
  }

  /// Checks duplicate UIDs inside the same squad
  static Map<String, dynamic> validateSquadUids(List<String> uids) {
    final clean = uids.map((u) => u.trim()).where((u) => u.isNotEmpty).toList();
    if (clean.length < 4) {
      return {'valid': false, 'msg': 'Please enter all 4 Squad Player Free Fire UIDs!'};
    }
    for (final uid in clean) {
      if (!isValidGameUid(uid)) {
        return {'valid': false, 'msg': 'Invalid Free Fire UID (\$uid)! UIDs must be 7-13 numeric digits.'};
      }
    }
    if (clean.toSet().length != clean.length) {
      return {'valid': false, 'msg': 'Duplicate Player UIDs found in the same squad! Each player must have a unique UID.'};
    }
    return {'valid': true, 'msg': 'All 4 Squad UIDs verified!'};
  }

  /// NPCI 12-Digit Numeric UTR Verification
  static Map<String, dynamic> validateUtr(String utr, {String? userVoucher}) {
    final clean = utr.trim().toUpperCase();

    // Check for 400-Coin Free Match Entry Voucher
    if (_voucherRegex.hasMatch(clean)) {
      if (userVoucher != null && userVoucher.toUpperCase() == clean) {
        return {'valid': true, 'isVoucher': true, 'reason': '400-Coin Free Slot Voucher Verified!'};
      }
      return {'valid': false, 'isVoucher': true, 'reason': 'Invalid or unassigned Free Slot Voucher!'};
    }

    if (!_utrRegex.hasMatch(clean)) {
      return {'valid': false, 'isVoucher': false, 'reason': 'UTR must be exactly 12 numeric digits (0-9)!'};
    }

    // Block repeating single-digit test sequences (e.g., 111111111111)
    if (RegExp(r'^(\d)\1{11}$').hasMatch(clean)) {
      return {'valid': false, 'isVoucher': false, 'reason': 'Fake repeating digits detected! Enter genuine 12-digit UTR.'};
    }

    // High-Entropy Check: Ensure at least 4 distinct digits
    if (clean.split('').toSet().length < 4) {
      return {'valid': false, 'isVoucher': false, 'reason': 'Low-entropy spoofed UTR blocked by AI Security!'};
    }

    return {'valid': true, 'isVoucher': false, 'reason': '12-Digit NPCI UPI Ref Verified ✓'};
  }

  /// Deterministic SHA-256 Hasher for Local Secure Caching
  static String computeHash(String raw) {
    final bytes = utf8.encode(raw);
    return sha256.convert(bytes).toString();
  }
}
