class SquadTeam {
  final String id;
  final String teamId;
  final String teamName;
  final String leaderName;
  final String hometown;
  final String phoneNumber;
  final String gameUid;
  final String member2Uid;
  final String member3Uid;
  final String member4Uid;
  final String? sub1Uid;
  final String? sub2Uid;
  final String matchId;
  final String slotGroup;
  final String transitionId;
  final String userEmail;
  final bool isVerified;
  final String status;
  final String? rejectReason;

  SquadTeam({
    required this.id,
    required this.teamId,
    required this.teamName,
    required this.leaderName,
    required this.hometown,
    required this.phoneNumber,
    required this.gameUid,
    required this.member2Uid,
    required this.member3Uid,
    required this.member4Uid,
    this.sub1Uid,
    this.sub2Uid,
    required this.matchId,
    required this.slotGroup,
    required this.transitionId,
    required this.userEmail,
    required this.isVerified,
    required this.status,
    this.rejectReason,
  });

  factory SquadTeam.fromMaps(Map<String, dynamic> pub, Map<String, dynamic> priv, String id) {
    return SquadTeam(
      id: id,
      teamId: pub['teamId'] ?? 'T100',
      teamName: (pub['teamName'] ?? 'Squad').toString().toUpperCase(),
      leaderName: pub['leaderName'] ?? 'Leader',
      hometown: priv['hometown'] ?? pub['hometown'] ?? '',
      phoneNumber: priv['phoneNumber'] ?? '',
      gameUid: pub['gameUid'] ?? '',
      member2Uid: pub['member2Uid'] ?? '',
      member3Uid: pub['member3Uid'] ?? '',
      member4Uid: pub['member4Uid'] ?? '',
      sub1Uid: pub['sub1Uid'],
      sub2Uid: pub['sub2Uid'],
      matchId: pub['matchId'] ?? '',
      slotGroup: pub['slotGroup'] ?? 'TEAM A',
      transitionId: priv['transitionId'] ?? '',
      userEmail: priv['userEmail'] ?? pub['userEmail'] ?? '',
      isVerified: pub['isVerified'] == true,
      status: pub['status'] ?? 'active',
      rejectReason: pub['rejectReason'],
    );
  }
}
