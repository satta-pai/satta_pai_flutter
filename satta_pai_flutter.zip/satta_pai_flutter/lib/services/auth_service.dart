import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  UserModel? _userModel;
  bool _isLoading = true;

  bool get isLoading => _isLoading;
  bool get isLoggedIn => _userModel != null && _userModel!.email != 'guest';
  UserModel get currentUser => _userModel ?? UserModel(
    uid: '',
    email: 'guest',
    username: 'Guest Player',
    ign: 'Guest',
    gameUid: '',
    playerId: 'SP-0000',
    spCoins: 0,
    isPremium: false,
    isProPlus: false,
    premiumUntil: 0,
    proPlusUntil: 0,
    hasVBadge: false,
    isSuperAdmin: false,
    isBanned: false,
    banReason: '',
    probationUntil: 0,
    bpBonusXp: 0,
    lastBpDaily: 0,
    claimedMailIds: [],
    deletedMailIds: [],
  );

  AuthService() {
    _initAuth();
  }

  void _initAuth() {
    _auth.authStateChanges().listen((User? user) async {
      if (user != null && user.email != null) {
        await _fetchOrInitUserProfile(user);
      } else {
        _userModel = null;
      }
      _isLoading = false;
      notifyListeners();
    });
  }

  /// Strictly verifies Super Admin status using Firebase Auth UID against Firestore 'superAdmin'
  Future<bool> _verifySuperAdminByUid(String uid) async {
    if (uid.trim().isEmpty) return false;
    try {
      // 1. Check top-level collection 'superAdmin/{uid}' or docs inside 'superAdmin'
      final directDoc = await _db.collection('superAdmin').doc(uid).get();
      if (directDoc.exists) return true;

      final superCol = await _db.collection('superAdmin').get();
      for (final d in superCol.docs) {
        final data = d.data();
        if (d.id == uid || data['uid'] == uid || data['superAdmin'] == uid) {
          return true;
        }
      }
    } catch (_) {}

    try {
      // 2. Check 'settings/superAdmin' -> field 'uid'
      final settingsSuper = await _db.collection('settings').doc('superAdmin').get();
      if (settingsSuper.exists) {
        final sd = settingsSuper.data() ?? {};
        if (sd['uid'] == uid || sd['superAdmin'] == uid) return true;
      }
    } catch (_) {}

    try {
      // 3. Check 'settings/config' -> field 'superAdmin' or 'superAdminUid'
      final cfgDoc = await _db.collection('settings').doc('config').get();
      if (cfgDoc.exists) {
        final cd = cfgDoc.data() ?? {};
        if (cd['superAdmin'] == uid || cd['superAdminUid'] == uid) return true;
      }
    } catch (_) {}

    return false;
  }

  Future<void> _fetchOrInitUserProfile(User user) async {
    final email = user.email!.toLowerCase();
    final uid = user.uid;
    final isSuper = await _verifySuperAdminByUid(uid);
    final docRef = _db.collection('users').doc(email);
    final snap = await docRef.get();

    if (snap.exists) {
      _userModel = UserModel.fromMap(snap.data()!, email, uid: uid, isSuperAdmin: isSuper);
    } else {
      final newDoc = {
        'uid': uid,
        'email': email,
        'username': user.displayName ?? email.split('@')[0],
        'ign': '',
        'gameUid': '',
        'playerId': 'SP-${(email.hashCode.abs() % 9000 + 1000)}',
        'spCoins': 0,
        'isPremium': false,
        'isProPlus': false,
        'premiumUntil': 0,
        'proPlusUntil': 0,
        'hasVBadge': false,
        'isBanned': false,
        'banReason': '',
        'probationUntil': 0,
        'bpBonusXp': 0,
        'lastBpDaily': 0,
        'claimedMailIds': [],
        'deletedMailIds': [],
        'updatedAt': DateTime.now().millisecondsSinceEpoch,
      };
      await docRef.set(newDoc, SetOptions(merge: true));
      _userModel = UserModel.fromMap(newDoc, email, uid: uid, isSuperAdmin: isSuper);
    }
    notifyListeners();
  }

  void enterGuestMode() {
    _userModel = UserModel(
      uid: '',
      email: 'guest',
      username: 'Guest Player',
      ign: 'Guest',
      gameUid: '',
      playerId: 'SP-0000',
      spCoins: 0,
      isPremium: false,
      isProPlus: false,
      premiumUntil: 0,
      proPlusUntil: 0,
      hasVBadge: false,
      isSuperAdmin: false,
      isBanned: false,
      banReason: '',
      probationUntil: 0,
      bpBonusXp: 0,
      lastBpDaily: 0,
      claimedMailIds: [],
      deletedMailIds: [],
    );
    notifyListeners();
  }

  Future<void> signOut() async {
    await _auth.signOut();
    _userModel = null;
    notifyListeners();
  }
}
