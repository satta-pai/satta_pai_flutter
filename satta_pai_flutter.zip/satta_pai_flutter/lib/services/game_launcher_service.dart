import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

enum FreeFireEdition { max, standard, india }

class GameLauncherService {
  /// Direct launch without Play Store redirects
  static Future<bool> launchGame({
    required FreeFireEdition edition,
    String? roomId,
    String? roomPassword,
  }) async {
    if (roomId != null && roomId.isNotEmpty) {
      await Clipboard.setData(ClipboardData(text: roomId));
    }

    String intentUrl;
    String iosScheme;

    switch (edition) {
      case FreeFireEdition.max:
        intentUrl = 'intent://#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;package=com.dts.freefiremax;end';
        iosScheme = 'freefiremax://';
        break;
      case FreeFireEdition.standard:
        intentUrl = 'intent://#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;package=com.dts.freefireth;end';
        iosScheme = 'freefire://';
        break;
      case FreeFireEdition.india:
        intentUrl = 'intent://#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;package=com.garena.game.ffi;end';
        iosScheme = 'freefirein://';
        break;
    }

    try {
      final uri = Uri.parse(intentUrl);
      if (await canLaunchUrl(uri)) {
        return await launchUrl(uri, mode: LaunchMode.externalNonBrowserApplication);
      } else {
        final iosUri = Uri.parse(iosScheme);
        if (await canLaunchUrl(iosUri)) {
          return await launchUrl(iosUri, mode: LaunchMode.externalNonBrowserApplication);
        }
      }
    } catch (_) {}
    return false;
  }
}
