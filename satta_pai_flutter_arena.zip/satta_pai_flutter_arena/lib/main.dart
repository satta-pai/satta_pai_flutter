import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Color(0xFF090D16),
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF090D16),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const SattaPaiHybridApp());
}

class SattaPaiHybridApp extends StatelessWidget {
  const SattaPaiHybridApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Satta Pai',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF090D16),
        primaryColor: const Color(0xFF10B981),
      ),
      home: const SattaPaiArenaShell(),
    );
  }
}

class SattaPaiArenaShell extends StatefulWidget {
  const SattaPaiArenaShell({super.key});

  @override
  State<SattaPaiArenaShell> createState() => _SattaPaiArenaShellState();
}

class _SattaPaiArenaShellState extends State<SattaPaiArenaShell> {
  WebViewController? _controller;
  HttpServer? _localServer;
  bool _isReady = false;

  @override
  void initState() {
    super.initState();
    _startLocalArenaEngine();
  }

  Future<void> _startLocalArenaEngine() async {
    try {
      // Load the complete Satta Pai HTML/CSS/JS Arena bundle from encrypted Flutter assets
      final String htmlContent = await rootBundle.loadString('assets/www/index.html');

      // 🚀 STATIC LOCAL PORT 8765: Preserves localStorage, IndexedDB & Firebase Auth tokens across all app launches!
      int port = 8765;
      try {
        _localServer = await HttpServer.bind(InternetAddress.loopbackIPv4, port);
      } catch (_) {
        try {
          port = 8766;
          _localServer = await HttpServer.bind(InternetAddress.loopbackIPv4, port);
        } catch (_) {
          _localServer = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
          port = _localServer!.port;
        }
      }

      _localServer!.listen((HttpRequest request) async {
        request.response.headers.contentType = ContentType.html;
        request.response.headers.add('Access-Control-Allow-Origin', '*');
        request.response.write(htmlContent);
        await request.response.close();
      });

      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFF090D16))
        // Use standard Chrome Mobile User-Agent so Google Sign-In works seamlessly without WebView blocks
        ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
        )
        ..setNavigationDelegate(
          NavigationDelegate(
            onNavigationRequest: (NavigationRequest request) {
              final String url = request.url;

              // Intercept native app schemes (Free Fire India/MAX, UPI, WhatsApp, Telegram, mailto)
              if (url.startsWith('intent://') ||
                  url.startsWith('freefire://') ||
                  url.startsWith('freefiremax://') ||
                  url.startsWith('upi://') ||
                  url.startsWith('whatsapp://') ||
                  url.startsWith('tg://') ||
                  url.startsWith('mailto:') ||
                  url.contains('whatsapp.com/channel/') ||
                  url.contains('t.me/') ||
                  url.contains('play.google.com/store')) {
                _launchExternalAppUrl(url);
                return NavigationDecision.prevent;
              }
              return NavigationDecision.navigate;
            },
          ),
        )
        ..loadRequest(Uri.parse('http://localhost:$port/index.html'));

      if (mounted) {
        setState(() {
          _controller = controller;
          _isReady = true;
        });
      }
    } catch (e) {
      // Fallback to live GitHub Pages site if local loopback fails
      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFF090D16))
        ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
        )
        ..loadRequest(Uri.parse('https://satta-pai.github.io/'));
      if (mounted) {
        setState(() {
          _controller = controller;
          _isReady = true;
        });
      }
    }
  }

  Future<void> _launchExternalAppUrl(String url) async {
    try {
      if (url.startsWith('intent://')) {
        // Parse Android intent:// URI for Free Fire MAX, Standard & Free Fire India (com.garena.game.ffi)
        final pkgMatch = RegExp(r'package=([a-zA-Z0-9._]+)').firstMatch(url);
        if (pkgMatch != null) {
          final pkg = pkgMatch.group(1)!;
          final marketUri = Uri.parse('market://details?id=$pkg');
          if (await canLaunchUrl(marketUri)) {
            await launchUrl(marketUri, mode: LaunchMode.externalApplication);
            return;
          }
        }
        return;
      }
      final uri = Uri.parse(url);
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  void dispose() {
    _localServer?.close(force: true);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) async {
        if (didPop) return;
        if (_controller != null && await _controller!.canGoBack()) {
          await _controller!.goBack();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF090D16),
        body: SafeArea(
          child: _isReady && _controller != null
              ? WebViewWidget(controller: _controller!)
              : const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(color: Color(0xFF10B981)),
                      SizedBox(height: 14),
                      Text(
                        '👑 SATTA PAI ARENA LOADING...',
                        style: TextStyle(
                          color: Color(0xFF10B981),
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}
